<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AKUN BERHASIL</title>
    <link rel="stylesheet" href="akun.css">
</head>
<body>
    <div class="container">
    <p>Akun berhasil dibuat!<br>
        Halo <?php echo $_POST['username']; ?><br>
        <a href="login.php">LOGIN</a> 
    </p>
    </div>
</body>
</html>